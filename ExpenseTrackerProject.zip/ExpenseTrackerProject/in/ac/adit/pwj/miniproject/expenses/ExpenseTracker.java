package in.ac.adit.pwj.miniproject.expenses;

import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class ExpenseTracker extends JFrame {

    abstract class Expense {
        protected String description;
        protected double amount;
        protected String type;
        protected String action;
        protected String date;
        protected String day;

        public Expense(String description, double amount, String type, String action) {
            this.description = description;
            this.amount = amount;
            this.type = type;
            this.action = action;

            LocalDate today = LocalDate.now();
            this.date = today.toString();
            this.day = today.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.ENGLISH);
        }

        public abstract String getCategory();
    }

    class Food extends Expense {
        public Food(String description, double amount, String type, String action) {
            super(description, amount, type, action);
        }

        public String getCategory() {
            return "Food";
        }
    }

    class Travel extends Expense {
        public Travel(String description, double amount, String type, String action) {
            super(description, amount, type, action);
        }

        public String getCategory() {
            return "Travel";
        }
    }

    private final java.util.List<Expense> expenses = Collections.synchronizedList(new ArrayList<>());
    private final Map<String, Double> categoryBudgets = new HashMap<>();

    private final JTextField descriptionField = new JTextField(15);
    private final JTextField amountField = new JTextField(10);
    private final JComboBox<String> categoryBox = new JComboBox<>(new String[]{"Food", "Travel"});
    private final JComboBox<String> typeBox = new JComboBox<>(new String[]{"Credit", "Debit"});
    private final JComboBox<String> actionBox = new JComboBox<>(new String[]{"Cash", "Card", "UPI"});
    private final JTextArea reportArea = new JTextArea(10, 30);
    private final JButton addButton = new JButton("➕ Add Expense");
    private final JButton reportButton = new JButton("📄 Generate Report");
    private final JButton clearButton = new JButton("Clear All");

    public ExpenseTracker() {
        super("💰 Expense Tracker");

        categoryBudgets.put("Food", 1000.0);
        categoryBudgets.put("Travel", 2000.0);

        Font font = new Font("Segoe UI", Font.BOLD, 14);
        Color bgColor = new Color(245, 255, 250);
        Color btnColor = new Color(72, 133, 237);
        Color labelColor = new Color(25, 25, 112);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(bgColor);
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setBackground(bgColor);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel descLabel = new JLabel("📝 Description:");
        JLabel amtLabel = new JLabel("💵 Amount:");
        JLabel catLabel = new JLabel("📂 Category:");
        JLabel typeLabel = new JLabel("🔁 Type:");
        JLabel actionLabel = new JLabel("⚙ Action:");

        JLabel[] labels = {descLabel, amtLabel, catLabel, typeLabel, actionLabel};
        for (JLabel label : labels) {
            label.setFont(font);
            label.setForeground(labelColor);
        }

        addButton.setBackground(btnColor);
        addButton.setForeground(Color.WHITE);
        addButton.setFont(font);
        reportButton.setBackground(Color.ORANGE);
        reportButton.setFont(font);
        reportButton.setForeground(Color.WHITE);
        clearButton.setBackground(new Color(220, 53, 69));
        clearButton.setForeground(Color.WHITE);
        clearButton.setFont(font);

        gbc.gridx = 0; gbc.gridy = 0; inputPanel.add(descLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 0; inputPanel.add(descriptionField, gbc);
        gbc.gridx = 0; gbc.gridy = 1; inputPanel.add(amtLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 1; inputPanel.add(amountField, gbc);
        gbc.gridx = 0; gbc.gridy = 2; inputPanel.add(catLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 2; inputPanel.add(categoryBox, gbc);
        gbc.gridx = 0; gbc.gridy = 3; inputPanel.add(typeLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 3; inputPanel.add(typeBox, gbc);
        gbc.gridx = 0; gbc.gridy = 4; inputPanel.add(actionLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 4; inputPanel.add(actionBox, gbc);
        gbc.gridx = 0; gbc.gridy = 5; inputPanel.add(addButton, gbc);
        gbc.gridx = 1; gbc.gridy = 5; inputPanel.add(reportButton, gbc);

        JPanel reportPanel = new JPanel(new BorderLayout());
        reportPanel.setBorder(BorderFactory.createTitledBorder("Transaction History"));
        reportArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        reportArea.setEditable(false);
        reportArea.setBackground(Color.WHITE);
        reportArea.setLineWrap(true);
        reportArea.setWrapStyleWord(true);
        reportPanel.add(new JScrollPane(reportArea), BorderLayout.CENTER);

        JPanel clearPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        clearPanel.setBackground(bgColor);
        clearPanel.add(clearButton);
        reportPanel.add(clearPanel, BorderLayout.SOUTH);

        mainPanel.add(inputPanel, BorderLayout.NORTH);
        mainPanel.add(reportPanel, BorderLayout.CENTER);

        add(mainPanel);

        addButton.addActionListener(e -> new Thread(this::logExpense).start());
        reportButton.addActionListener(e -> new ReportGenerator().generate());
        clearButton.addActionListener(e -> clearAll());

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 600);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void clearAll() {
        synchronized (expenses) {
            expenses.clear();
        }
        reportArea.setText("");
        JOptionPane.showMessageDialog(this, "All transactions cleared!");
    }

    private void logExpense() {
        try {
            String desc = descriptionField.getText();
            double amt = Double.parseDouble(amountField.getText());
            String cat = (String) categoryBox.getSelectedItem();
            String type = (String) typeBox.getSelectedItem();
            String action = (String) actionBox.getSelectedItem();

            if (amt <= 0) throw new IllegalArgumentException("Amount must be positive.");

            Expense expense = "Food".equals(cat)
                    ? new Food(desc, amt, type, action)
                    : new Travel(desc, amt, type, action);

            synchronized (expenses) {
                expenses.add(expense);
            }

            checkBudget(expense);
            saveExpenseToFile(expense);
            JOptionPane.showMessageDialog(this, "✅ Expense added successfully!");

        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(this, "❌ Invalid amount entered.");
        } catch (IllegalArgumentException iae) {
            JOptionPane.showMessageDialog(this, "❌ " + iae.getMessage());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "❗ Error: " + ex.getMessage());
        }
    }

    private void checkBudget(Expense expense) throws Exception {
        String cat = expense.getCategory();
        double total = 0;
        synchronized (expenses) {
            for (Expense e : expenses) {
                if (e.getCategory().equals(cat)) {
                    total += e.amount;
                }
            }
        }

        if (total > categoryBudgets.getOrDefault(cat, Double.MAX_VALUE)) {
            throw new Exception("⚠ Budget exceeded for " + cat);
        }
    }

    private void saveExpenseToFile(Expense expense) {
        try (FileWriter writer = new FileWriter("expenses.txt", true)) {
            writer.write(
                    expense.getCategory() + " - " +
                            expense.description + " : ₹" +
                            expense.amount + " | " +
                            expense.type + " | " +
                            expense.action + " | " +
                            expense.date + " (" + expense.day + ")\n"
            );
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    class ReportGenerator {
        void generate() {
            StringBuilder sb = new StringBuilder();
            Map<String, Double> totals = new HashMap<>();

            synchronized (expenses) {
                for (Expense e : expenses) {
                    totals.put(e.getCategory(), totals.getOrDefault(e.getCategory(), 0.0) + e.amount);
                }
            }

            for (String cat : totals.keySet()) {
                sb.append(cat).append(" Total: ₹").append(totals.get(cat)).append("\n\n");
            }

            sb.append("Detailed Report:\n\n");
            synchronized (expenses) {
                for (Expense e : expenses) {
                    sb.append("Category: ").append(e.getCategory()).append("\n")
                            .append("Description: ").append(e.description).append("\n")
                            .append("Amount: ₹").append(e.amount).append("\n")
                            .append("Type: ").append(e.type).append("\n")
                            .append("Action: ").append(e.action).append("\n")
                            .append("Date: ").append(e.date).append("\n")
                            .append("Day: ").append(e.day).append("\n\n");
                }
            }

            reportArea.setText(sb.toString());

            try (FileWriter writer = new FileWriter("report.txt")) {
                writer.write(sb.toString());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ExpenseTracker::new);
    }
}

